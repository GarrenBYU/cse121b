mysqldump --skip-add-drop-table --no-data --result-file=schema.txt scriptures
mysqldump --skip-add-drop-table --result-file=lds-scriptures-mysql.sql scriptures
